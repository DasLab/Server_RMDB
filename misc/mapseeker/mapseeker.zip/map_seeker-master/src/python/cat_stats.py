#!/usr/bin/python

import sys
from cat_stats_stuff import cat_stats

outdirs = sys.argv[1:]
cat_stats( outdirs )
